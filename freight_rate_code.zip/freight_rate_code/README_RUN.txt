Freight Rate Prediction - run instructions

1. Keep the data files inside data/ (the scripts accept hyphen/underscore names).
2. Activate the virtual environment:
   source .venv/bin/activate
3. Copy these files into the project root. Keep results/roundF_window_predictions.csv.
4. Run checks:
   python 03_final.py --data data --out results --step checks
5. Run the one-time October evaluation:
   python 03_final.py --data data --out results --step october
6. Generate final predictions:
   python 03_final.py --data data --out results --step predict
7. Validate and generate the chart:
   python score.py --predictions results/validation_predictions.csv --december-predictions results/december_chart_inputs.csv --output-dir scorer_results

Final files are created under results/.
